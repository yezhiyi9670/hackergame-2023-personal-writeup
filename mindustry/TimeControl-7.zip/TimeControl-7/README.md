# TimeControl
Speeds up or slows down Mindustry.   

Supports `x1/256` ~ `x256`. Simply drag the slider to adjust the speed.   

Not intended for multiplayer use.   
